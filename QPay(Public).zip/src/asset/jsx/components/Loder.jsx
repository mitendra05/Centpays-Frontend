import React from 'react';

const Loader = () => {
  return (
    <div className="table-loader">
        <div className="container"></div>
    </div>
  );
}

export default Loader;
